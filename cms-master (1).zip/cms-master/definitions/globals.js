PAUSESERVER('database', true);
setTimeout(() => PAUSESERVER('database', false), 1000);